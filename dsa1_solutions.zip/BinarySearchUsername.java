
import java.util.Arrays;

public class BinarySearchUsername {
    public static boolean findUsername(String[] users, String target) {
        Arrays.sort(users);
        int left = 0, right = users.length - 1;

        while (left <= right) {
            int mid = (left + right) / 2;
            int cmp = users[mid].compareTo(target);

            if (cmp == 0) return true;
            else if (cmp < 0) left = mid + 1;
            else right = mid - 1;
        }
        return false;
    }
}
