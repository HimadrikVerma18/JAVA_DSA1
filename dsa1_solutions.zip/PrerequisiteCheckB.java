
import java.util.HashSet;

public class PrerequisiteCheckB {
    public static boolean check(int[] completed, int[] prerequisites) {
        HashSet<Integer> set = new HashSet<>();
        for (int c : completed) set.add(c);
        for (int pre : prerequisites)
            if (!set.contains(pre)) return false;
        return true;
    }
}
