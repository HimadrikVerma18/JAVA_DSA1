
public class AverageTemperature {
    public static double findAverage(int[] temperature) {
        int total = 0;
        for (int t : temperature) total += t;
        return (double) total / temperature.length;
    }

    public static void main(String[] args) {
        int[] temp = {20, 25, 22, 24, 21};
        System.out.println("Average = " + findAverage(temp));
    }
}
