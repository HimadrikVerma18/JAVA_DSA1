
import java.util.HashSet;

public class HashSearch {
    public static boolean findUsername(String[] users, String target) {
        HashSet<String> set = new HashSet<>();
        for (String user : users) set.add(user);
        return set.contains(target);
    }
}
