
public class PrerequisiteCheckA {
    public static boolean check(int[] completed, int[] prerequisites) {
        for (int pre : prerequisites) {
            boolean found = false;
            for (int c : completed) {
                if (pre == c) {
                    found = true;
                    break;
                }
            }
            if (!found) return false;
        }
        return true;
    }
}
