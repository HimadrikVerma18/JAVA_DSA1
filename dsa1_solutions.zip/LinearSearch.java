
public class LinearSearch {
    public static boolean findUsername(String[] users, String target) {
        for (String user : users) {
            if (user.equals(target)) return true;
        }
        return false;
    }
}
